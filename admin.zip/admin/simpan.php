<?php
require '../koneksi.php';
  function daftar($data)
  {
    global $koneksi;
 
    $jn_info = $data['jn_info'];
    $kategory_ternak = $data['kategory_ternak'];
    $info = $data['info'];
    $data = mysqli_query($koneksi,"INSERT INTO Tbl_info VALUES('','$jn_info','$kategory_ternak','$info)");
    if (!$data) {
      echo "<script>
               alert('gagal terdaftar atau anda sudah melakukan pendaftaran sebelumnya');history.go(-1);
               </script>";
               return false;
    }else {
      echo "<script>
             alert('berhasil terdaftar');history.go(1);
             </script>";
    }
    return 1;
  }
?>
