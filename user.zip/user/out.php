<?php

     session_start();
     $_SESSION["user_NIK"];
     $_SESSION["user_password"];

     unset($_SESSION["use_NIK"]);
     unset($_SESSION["user_password"]);

     session_unset();
     session_destroy();

     header("location:login.php");

?>