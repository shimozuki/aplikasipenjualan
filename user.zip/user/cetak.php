<?php
  session_start();
   if(!isset($_SESSION["login"])){
     header("location:login.php");
     exit;
   }
   include '../koneksi.php';
   $query = mysqli_query($koneksi, "SELECT user.Nama, user.Alamat, hewan.id_hewan, hewan.jenis_hewan, hewan.ciri_hewan, hewan.jumlah_hewan, hewan.jml_betina, hewan.jml_jantan, hewan.jml_anak
   FROM user
   INNER JOIN hewan ON user.Nik = hewan.Nik where user.Nik = 1234567890");
?>

<!DOCTYPE html>
<html>
<head>
	<title>cetak Kartu</title>
</head>
<body>
	<center>
    <img src="img/logoternak.png" width="100px" height="100px">
		<h2>KARTU DATA HEWAN PETERNAK</h2>
        <h4>DINAS PETERNAKAN</h4>
        <h3>___________________________________________________________________________________________________________________________________________</h3>
	</center>
    <?php while ($row=mysqli_fetch_array($query)): ?>
    <p><br/><b>Nama :<?php echo $row['Nama']?></b>
    <br/><b>Alamat :<?php echo $row['Alamat'] ?></b>
    <br/><b>No Kartu :<?php echo $row['id_hewan']?></b>
    </p>
    <table border="1"  width="1000">
 <thead>
  <tr>
   <td>Jumlah hewan</td>
   <td>ciri-ciri Hewan</td>
   <td>jumlah hewan betina</td>
   <td>jumlah hewan jantan</td>
   <td>jumlah ternak usia 2th</td>
  </tr>
 </thead>
 <tbody>
  <tr>
   <td><?php echo $row['jumlah_hewan']?></td>
   <td><?php echo $row['ciri_hewan']?></td>
   <td><?php echo $row['jml_betina']?></td>
   <td><?php echo $row['jml_jantan']?></td>
   <td><?php echo $row['jml_anak']?></td>
  </tr>
 </tbody>
</table>
<?php endwhile; ?>
 
	<p>
		<b>ini adalah kartu perizinan peternak, jika hilang atau rusak segera lapor ke </b>
	</p>
 
	<script>
		window.print();
	</script>
	
</body>
</html>